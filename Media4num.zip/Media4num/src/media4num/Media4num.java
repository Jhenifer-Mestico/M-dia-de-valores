/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package media4num;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class Media4num {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float a,b,c,d,media;
        Scanner inputData = new Scanner(System.in);
    System.out.println("Digite o primeiro número:");
    a = inputData.nextFloat();
    System.out.println("Digite o segundo númmero:");
    b = inputData.nextFloat();
    System.out.println("Digite o terceiro númmero:");
    c = inputData.nextFloat();
    System.out.println("Digite o quarto númmero:");
    d = inputData.nextFloat();
    
    media = (a+b+c+d/4);
    System.out.println("A média dos valores é:" + media);
    }
    
}
